﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap so nguyen: ");
        int n = Convert.ToInt32(Console.ReadLine());

        if (n < 2)
        {
            Console.WriteLine(n + " khong phai so nguyen to");
            return;
        }

        bool laNguyenTo = true;
        for (int i = 2; i <= Math.Sqrt(n); i++)
        {
            if (n % i == 0)
            {
                laNguyenTo = false;
                break;
            }
        }

        if (laNguyenTo)
            Console.WriteLine(n + " la so nguyen to");
        else
            Console.WriteLine(n + " khong phai so nguyen to");
    }
}