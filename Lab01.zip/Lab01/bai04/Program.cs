﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap mot so nguyen: ");
        int so = Convert.ToInt32(Console.ReadLine());

        if (so % 2 == 0)
        {
            Console.WriteLine(so + " la so chan");
        }
        else
        {
            Console.WriteLine(so + " khong phai so chan");
        }
    }
}