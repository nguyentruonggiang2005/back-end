﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap nam: ");
        int nam = Convert.ToInt32(Console.ReadLine());

        bool laNamNhuan = (nam % 4 == 0 && nam % 100 != 0) || (nam % 400 == 0);

        if (laNamNhuan)
            Console.WriteLine(nam + " la nam nhuan");
        else
            Console.WriteLine(nam + " khong phai nam nhuan");
    }
}