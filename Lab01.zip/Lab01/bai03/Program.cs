﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap nhiet do (do C): ");
        double doC = Convert.ToDouble(Console.ReadLine());

        double doF = (doC * 9 / 5) + 32;

        Console.WriteLine("Nhiet do tuong ung (do F): " + doF);
    }
}