﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap so thu nhat: ");
        double so1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Nhap so thu hai: ");
        double so2 = Convert.ToDouble(Console.ReadLine());

        double tong = so1 + so2;
        double tich = so1 * so2;

        Console.WriteLine("Tong: " + tong);
        Console.WriteLine("Tich: " + tich);
    }
}