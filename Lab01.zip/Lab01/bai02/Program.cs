﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap chieu dai hinh chu nhat: ");
        double chieuDai = Convert.ToDouble(Console.ReadLine());

        Console.Write("Nhap chieu rong hinh chu nhat: ");
        double chieuRong = Convert.ToDouble(Console.ReadLine());

        double dienTich = chieuDai * chieuRong;

        Console.WriteLine("Dien tich hinh chu nhat la: " + dienTich);
    }
}