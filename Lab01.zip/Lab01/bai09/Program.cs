﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap so nguyen duong: ");
        int n = Convert.ToInt32(Console.ReadLine());

        if (n < 0)
        {
            Console.WriteLine("Vui long nhap so nguyen duong");
            return;
        }

        long giaiThua = 1;
        for (int i = 1; i <= n; i++)
        {
            giaiThua *= i;
        }

        Console.WriteLine($"Giai thua cua {n} la: {giaiThua}");
    }
}