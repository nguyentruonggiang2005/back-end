﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Nhap mot so: ");
        double so = Convert.ToDouble(Console.ReadLine());

        if (so > 0)
            Console.WriteLine(so + " la so duong");
        else if (so < 0)
            Console.WriteLine(so + " la so am");
        else
            Console.WriteLine("So bang 0");
    }
}